package com.cg.airlines.exception;

public class CustomerException extends Exception {
	String message;
	public CustomerException(String message)
	{
		this.message=message;
	}
	public String getmessage()
	{
		return this.message;
	}
}
